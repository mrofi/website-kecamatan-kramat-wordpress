<?php
/**
 * Functions - Child theme custom functions
 */


/*****************************************************************************************************************
Caution: do not remove this or you will lose all the customization capabilities created by Divi Children plugin */
require_once __DIR__.'/../web-resmi-kecamatan-kramat-kabupaten-tegal/functions.php';
/****************************************************************************************************************/


