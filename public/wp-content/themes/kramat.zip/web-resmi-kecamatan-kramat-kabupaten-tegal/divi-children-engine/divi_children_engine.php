<?php
/**
 * Divi Children Engine
 * Created by Divi Children plugin
 * Divi Children Engine Version: 1.0.3
 * Divi Children Plugin Version: 2.0.8
 * 
 * Copyright (C) 2014-2015, Luis Alejandre - luis@divi4u.com
 * http://divi4u.com
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/*****************************************************************************************************************
Caution: do not remove this or you will lose all the customization capabilities created by Divi Children plugin */
require_once('includes/divi_children_functions.php');
require_once('includes/custom_codes.php');
require_once('includes/divi-mods/divi_mod_functions.php');
/****************************************************************************************************************/


?>
